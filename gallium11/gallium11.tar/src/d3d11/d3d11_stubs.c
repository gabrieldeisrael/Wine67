#include <stdio.h>

void D3D11CreateDeviceAndSwapChain() {
    printf("D3D11CreateDeviceAndSwapChain stub called\n");
}
