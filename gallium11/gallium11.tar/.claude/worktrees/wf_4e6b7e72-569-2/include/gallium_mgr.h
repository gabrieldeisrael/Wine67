#ifndef GALLIUM_MGR_H
#define GALLIUM_MGR_H

#include <pipe/p_screen.h>
#include <pipe/p_context.h>

struct gallium_mgr {
    struct pipe_screen *screen;
    struct pipe_context *context;
};

int gallium_mgr_init(struct gallium_mgr *mgr);
void gallium_mgr_cleanup(struct gallium_mgr *mgr);

#endif
