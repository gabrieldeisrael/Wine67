#ifndef PIPE_STATE_H
#define PIPE_STATE_H
// Placeholder for Mesa Gallium pipe/p_state.h
#endif
