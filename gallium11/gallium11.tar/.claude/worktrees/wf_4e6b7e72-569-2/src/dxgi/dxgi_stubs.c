#include <stdio.h>

void CreateDXGIFactory() {
    printf("CreateDXGIFactory stub called\n");
}
