#include <stdio.h>
#include <stdlib.h>

typedef struct {
    float x, y, z, w;
    float r, g, b, a;
} vertex_t;

typedef struct {
    vertex_t *vertices;
    size_t count;
} mesh_t;

// Weak or stub declarations if not provided elsewhere
__attribute__((weak)) int parse_obj_file(const char *filename, mesh_t *mesh) {
    FILE *f = fopen(filename, "r");
    if (!f) return -1;
    fclose(f);
    return 0;
}

__attribute__((weak)) mesh_t get_default_cube_obj(void) {
    mesh_t m = {0};
    return m;
}

void load_cube_mesh(mesh_t *mesh) {
    if (parse_obj_file("utah_teapot.obj", mesh) != 0) {
        *mesh = get_default_cube_obj();
    }
}
