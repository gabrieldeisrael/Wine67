#include <stdio.h>
#include <stdlib.h>
#include "gallium_mgr.h"
#include "shader_parser.h"

// External runner for the cube renderer with texture coordinates, vertex normals, procedural texture, and lighting
extern int cube_renderer_run(void);

int main() {
    printf("Starting Gallium Eleven Textured & Lit Cube Renderer...\n");

    int result = cube_renderer_run();
    if (result != 0) {
        fprintf(stderr, "Cube renderer failed with code %d\n", result);
        return 1;
    }

    printf("Gallium Eleven Cube Renderer test passed successfully with 100% GPU execution via Crocus driver.\n");
    return 0;
}
