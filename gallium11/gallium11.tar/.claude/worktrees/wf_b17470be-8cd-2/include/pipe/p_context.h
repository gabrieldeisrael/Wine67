#ifndef P_CONTEXT_H
#define P_CONTEXT_H

#include <stdint.h>
#include <stddef.h>
#include "p_state.h"

struct pipe_constant_buffer {
    struct pipe_resource *buffer;
    unsigned buffer_offset;
    unsigned buffer_size;
    const void *user_buffer;
};

struct pipe_context {
    struct pipe_screen *screen;
    void *priv;
    void (*destroy)(struct pipe_context *);
    void *(*create_sampler_state)(struct pipe_context *, const struct pipe_sampler_state *);
    void (*bind_sampler_states)(struct pipe_context *, unsigned shader, unsigned start, unsigned num, void **states);
    void (*delete_sampler_state)(struct pipe_context *, void *);
    struct pipe_sampler_view *(*create_sampler_view)(struct pipe_context *, struct pipe_resource *, const struct pipe_sampler_view *);
    void (*sampler_view_destroy)(struct pipe_context *, struct pipe_sampler_view *);
    void (*set_sampler_views)(struct pipe_context *, unsigned shader, unsigned start, unsigned num, struct pipe_sampler_view **views);
    void (*set_constant_buffer)(struct pipe_context *, unsigned shader, unsigned index, const struct pipe_constant_buffer *);
    void (*buffer_subdata)(struct pipe_context *, struct pipe_resource *, unsigned usage, unsigned offset, unsigned size, const void *data);
    void (*draw_vbo)(struct pipe_context *, const struct pipe_draw_info *info);
};

#endif
