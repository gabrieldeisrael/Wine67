#ifndef P_SCREEN_H
#define P_SCREEN_H

#include <stdint.h>
#include <stddef.h>
#include "p_state.h"

struct pipe_context;

struct pipe_screen {
    int dummy;
    struct pipe_context *(*context_create)(struct pipe_screen *, void *priv, unsigned flags);
    void (*destroy)(struct pipe_screen *);
    struct pipe_resource *(*resource_create)(struct pipe_screen *, const struct pipe_resource *template);
    void (*resource_destroy)(struct pipe_screen *, struct pipe_resource *);
};

#endif
