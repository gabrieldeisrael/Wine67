#ifndef PIPE_STATE_H
#define PIPE_STATE_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

enum pipe_texture_target {
    PIPE_BUFFER,
    PIPE_TEXTURE_1D,
    PIPE_TEXTURE_2D,
    PIPE_TEXTURE_3D,
    PIPE_TEXTURE_CUBE,
    PIPE_TEXTURE_1D_ARRAY,
    PIPE_TEXTURE_2D_ARRAY,
    PIPE_TEXTURE_CUBE_ARRAY
};

enum pipe_format {
    PIPE_FORMAT_NONE = 0,
    PIPE_FORMAT_B8G8R8A8_UNORM,
    PIPE_FORMAT_R8G8B8A8_UNORM,
    PIPE_FORMAT_R32G32B32A32_FLOAT,
    PIPE_FORMAT_R32G32B32_FLOAT,
    PIPE_FORMAT_R32G32_FLOAT,
    PIPE_FORMAT_R32_FLOAT
};

#define PIPE_BIND_RENDER_TARGET (1 << 0)
#define PIPE_BIND_SAMPLER_VIEW  (1 << 1)
#define PIPE_BIND_VERTEX_BUFFER (1 << 2)
#define PIPE_BIND_INDEX_BUFFER  (1 << 3)
#define PIPE_BIND_CONSTANT_BUFFER (1 << 4)

#define PIPE_USAGE_DEFAULT      0
#define PIPE_USAGE_IMMUTABLE    1
#define PIPE_USAGE_DYNAMIC      2
#define PIPE_USAGE_STREAM       3

struct pipe_resource {
    struct pipe_screen *screen;
    enum pipe_texture_target target;
    enum pipe_format format;
    uint32_t width0;
    uint32_t height0;
    uint32_t depth0;
    uint32_t array_size;
    uint32_t last_level;
    uint32_t nr_samples;
    uint32_t bpp;
    uint32_t bind;
    uint32_t usage;
    uint32_t flags;
};

struct pipe_box {
    int x, y, z;
    int width, height, depth;
};

struct pipe_sampler_state {
    float lod_bias;
    float min_lod;
    float max_lod;
    float max_anisotropy;
    uint32_t wrap_s:3;
    uint32_t wrap_t:3;
    uint32_t wrap_r:3;
    uint32_t min_img_filter:2;
    uint32_t mag_img_filter:2;
    uint32_t min_mip_filter:2;
    uint32_t compare_mode:1;
    uint32_t compare_func:3;
    bool normalized_coords:1;
    bool seamless_cube_map:1;
};

struct pipe_sampler_view {
    struct pipe_resource *texture;
    struct pipe_screen *screen;
    enum pipe_format format;
    uint32_t usage;
    union {
        struct {
            uint32_t first_layer;
            uint32_t last_layer;
            uint32_t level;
        } dummy;
    } u;
};

struct pipe_vertex_element {
    unsigned src_offset;
    unsigned instance_divisor;
    unsigned vertex_buffer_index;
    enum pipe_format src_format;
};

struct pipe_vertex_buffer {
    unsigned stride;
    unsigned buffer_offset;
    struct pipe_resource *buffer;
    const void *user_buffer;
};

struct pipe_draw_info {
    bool indexed;
    unsigned start;
    unsigned count;
    unsigned mode;
    int index_bias;
    unsigned min_index;
    unsigned max_index;
    unsigned instance_count;
    unsigned start_instance;
    unsigned vertices_per_patch;
};

#endif
