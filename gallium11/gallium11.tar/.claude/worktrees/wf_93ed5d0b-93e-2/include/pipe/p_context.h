#ifndef P_CONTEXT_H
#define P_CONTEXT_H

#include "p_state.h"

struct pipe_screen;

struct pipe_context {
    struct pipe_screen *screen;
    void (*destroy)(struct pipe_context *context);
    void (*set_vertex_buffers)(struct pipe_context *context,
                               unsigned start_slot, unsigned num_buffers,
                               const struct pipe_vertex_buffer *buffers);
    void (*set_index_buffer)(struct pipe_context *context,
                             const struct pipe_index_buffer *ib);
    void (*draw_vbo)(struct pipe_context *context, const struct pipe_draw_info *info);
};

#endif
