#ifndef P_STATE_H
#define P_STATE_H

#include <stdint.h>
#include <stdbool.h>

#define PIPE_PRIMITIVE_TRIANGLES 4
#define PIPE_BIND_VERTEX_BUFFER (1 << 0)
#define PIPE_BIND_INDEX_BUFFER  (1 << 1)
#define PIPE_USAGE_DEFAULT      0
#define PIPE_BUFFER             0

struct pipe_resource;

struct pipe_vertex_buffer {
    unsigned stride;
    unsigned buffer_offset;
    struct pipe_resource *buffer;
    const void *user_buffer;
};

struct pipe_index_buffer {
    unsigned index_size;
    unsigned offset;
    struct pipe_resource *buffer;
    const void *user_buffer;
};

struct pipe_draw_info {
    uint8_t mode;
    uint8_t indexed;
    uint8_t has_user_indices;
    uint8_t has_user_vertices;
    unsigned start;
    unsigned count;
    unsigned start_instance;
    unsigned instance_count;
    int index_bias;
    unsigned min_index;
    unsigned max_index;
    union {
        const void *user;
        struct pipe_resource *resource;
    } indices;
};

#endif
