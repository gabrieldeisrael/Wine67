#ifndef P_SCREEN_H
#define P_SCREEN_H

#include <stdint.h>
#include <stddef.h>

struct pipe_screen;

struct pipe_resource {
    struct pipe_screen *screen;
    unsigned target;
    unsigned format;
    unsigned width0;
    unsigned height0;
    unsigned depth0;
    unsigned array_size;
    unsigned last_level;
    unsigned nr_samples;
    unsigned usage;
    unsigned bind;
    unsigned flags;
    void *driver_private;
};

struct pipe_resource_template {
    unsigned target;
    unsigned format;
    unsigned width0;
    unsigned height0;
    unsigned depth0;
    unsigned array_size;
    unsigned last_level;
    unsigned nr_samples;
    unsigned usage;
    unsigned bind;
    unsigned flags;
};

struct pipe_screen {
    void (*destroy)(struct pipe_screen *screen);
    struct pipe_resource* (*resource_create)(struct pipe_screen *screen,
                                              const struct pipe_resource_template *templ);
    void (*resource_destroy)(struct pipe_screen *screen, struct pipe_resource *resource);
};

#endif
