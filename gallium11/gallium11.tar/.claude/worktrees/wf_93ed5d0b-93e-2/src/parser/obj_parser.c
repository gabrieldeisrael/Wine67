#include "obj_parser.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Built-in test OBJ strings
const char* get_default_cube_obj(void) {
    return
        "# Cube OBJ\n"
        "v -0.5  0.5 -0.5\n"
        "v -0.5 -0.5 -0.5\n"
        "v  0.5 -0.5 -0.5\n"
        "v  0.5  0.5 -0.5\n"
        "v -0.5  0.5  0.5\n"
        "v -0.5 -0.5  0.5\n"
        "v  0.5 -0.5  0.5\n"
        "v  0.5  0.5  0.5\n"
        "vn  0.0  0.0 -1.0\n"
        "vn  0.0  0.0  1.0\n"
        "vn  0.0  1.0  0.0\n"
        "vn  0.0 -1.0  0.0\n"
        "vn -1.0  0.0  0.0\n"
        "vn  1.0  0.0  0.0\n"
        "f 1//1 2//1 3//1\n"
        "f 1//1 3//1 4//1\n"
        "f 5//2 7//2 6//2\n"
        "f 5//2 8//2 7//2\n"
        "f 1//3 5//3 8//3\n"
        "f 1//3 8//3 4//3\n"
        "f 2//4 6//4 7//4\n"
        "f 2//4 7//4 3//4\n"
        "f 4//6 3//6 7//6\n"
        "f 4//6 7//6 8//6\n"
        "f 1//5 2//5 6//5\n"
        "f 1//5 6//5 5//5\n";
}

const char* get_default_torus_obj(void) {
    return
        "# Simple Torus placeholder OBJ\n"
        "v  1.0 0.0 0.0\n"
        "v  0.0 1.0 0.0\n"
        "v -1.0 0.0 0.0\n"
        "v  0.0 -1.0 0.0\n"
        "vn 1.0 0.0 0.0\n"
        "vn 0.0 1.0 0.0\n"
        "vn -1.0 0.0 0.0\n"
        "vn 0.0 -1.0 0.0\n"
        "f 1//1 2//2 3//3\n"
        "f 1//1 3//3 4//4\n";
}

const char* get_default_sphere_obj(void) {
    return get_default_cube_obj();
}

typedef struct {
    int v;
    int vt;
    int vn;
} obj_vertex_ref_t;

typedef struct {
    float x, y, z;
} vec3_t;

typedef struct {
    float u, v;
} vec2_t;

int parse_obj_string(const char *obj_content, obj_mesh_t *out_mesh) {
    if (!obj_content || !out_mesh) return -1;

    memset(out_mesh, 0, sizeof(obj_mesh_t));

    // Dynamic arrays for raw OBJ data
    size_t v_cap = 256, v_count = 0;
    size_t vt_cap = 256, vt_count = 0;
    size_t vn_cap = 256, vn_count = 0;

    vec3_t *positions = malloc(v_cap * sizeof(vec3_t));
    vec2_t *texcoords = malloc(vt_cap * sizeof(vec2_t));
    vec3_t *normals = malloc(vn_cap * sizeof(vec3_t));

    // Temporary storage for parsed faces (triangles)
    size_t face_cap = 512, face_count = 0;
    obj_vertex_ref_t *face_refs = malloc(face_cap * 3 * sizeof(obj_vertex_ref_t));

    char *line_buf = strdup(obj_content);
    char *cursor = line_buf;
    char *line;

    while ((line = strtok_r(cursor, "\r\n", &cursor)) != NULL) {
        // Skip whitespace / comments
        while (*line == ' ' || *line == '\t') line++;
        if (*line == '#' || *line == '\0') continue;

        if (strncmp(line, "v ", 2) == 0) {
            float x = 0, y = 0, z = 0, w = 1.0f;
            if (sscanf(line + 2, "%f %f %f %f", &x, &y, &z, &w) < 3) {
                sscanf(line + 2, "%f %f %f", &x, &y, &z);
            }
            if (v_count >= v_cap) {
                v_cap *= 2;
                positions = realloc(positions, v_cap * sizeof(vec3_t));
            }
            positions[v_count++] = (vec3_t){x, y, z};
        } else if (strncmp(line, "vt ", 3) == 0) {
            float u = 0, v = 0;
            sscanf(line + 3, "%f %f", &u, &v);
            if (vt_count >= vt_cap) {
                vt_cap *= 2;
                texcoords = realloc(texcoords, vt_cap * sizeof(vec2_t));
            }
            texcoords[vt_count++] = (vec2_t){u, v};
        } else if (strncmp(line, "vn ", 3) == 0) {
            float nx = 0, ny = 0, nz = 0;
            sscanf(line + 3, "%f %f %f", &nx, &ny, &nz);
            if (vn_count >= vn_cap) {
                vn_cap *= 2;
                normals = realloc(normals, vn_cap * sizeof(vec3_t));
            }
            normals[vn_count++] = (vec3_t){nx, ny, nz};
        } else if (strncmp(line, "f ", 2) == 0) {
            // Parse face vertices (supports v, v/vt, v/vt/vn, v//vn)
            char *token;
            char *f_str = line + 2;
            obj_vertex_ref_t poly[16];
            int poly_count = 0;

            while ((token = strtok_r(f_str, " \t", &f_str)) != NULL) {
                if (poly_count >= 16) break;
                obj_vertex_ref_t ref = {0, 0, 0};

                // Parse v/vt/vn
                char *slash1 = strchr(token, '/');
                if (!slash1) {
                    ref.v = atoi(token);
                } else {
                    *slash1 = '\0';
                    ref.v = atoi(token);
                    char *slash2 = strchr(slash1 + 1, '/');
                    if (!slash2) {
                        ref.vt = atoi(slash1 + 1);
                    } else {
                        *slash2 = '\0';
                        if (slash1 + 1 < slash2) {
                            ref.vt = atoi(slash1 + 1);
                        }
                        ref.vn = atoi(slash2 + 1);
                    }
                }
                poly[poly_count++] = ref;
            }

            // Triangulate polygon (fan triangulation: 0, i, i+1)
            for (int i = 1; i + 1 < poly_count; i++) {
                if (face_count + 1 >= face_cap) {
                    face_cap *= 2;
                    face_refs = realloc(face_refs, face_cap * 3 * sizeof(obj_vertex_ref_t));
                }
                face_refs[face_count * 3 + 0] = poly[0];
                face_refs[face_count * 3 + 1] = poly[i];
                face_refs[face_count * 3 + 2] = poly[i + 1];
                face_count++;
            }
        }
    }

    free(line_buf);

    if (face_count == 0) {
        free(positions);
        free(texcoords);
        free(normals);
        free(face_refs);
        return -1;
    }

    // Deduplicate vertices into extended_vertex_t and build indices
    size_t max_vert = face_count * 3;
    extended_vertex_t *out_verts = malloc(max_vert * sizeof(extended_vertex_t));
    uint32_t *out_idxs = malloc(max_vert * sizeof(uint32_t));
    size_t unique_vert_count = 0;

    for (size_t i = 0; i < face_count * 3; i++) {
        obj_vertex_ref_t ref = face_refs[i];

        // Resolve 1-based / negative indices
        int v_idx = ref.v > 0 ? ref.v - 1 : (int)v_count + ref.v;
        int vt_idx = ref.vt > 0 ? ref.vt - 1 : (ref.vt < 0 ? (int)vt_count + ref.vt : -1);
        int vn_idx = ref.vn > 0 ? ref.vn - 1 : (ref.vn < 0 ? (int)vn_count + ref.vn : -1);

        // Check if this exact vertex attribute combination already exists
        int found_idx = -1;
        for (size_t j = 0; j < unique_vert_count; j++) {
            // Simple linear search for deduplication (fine for test meshes)
            // Or we can match v_idx, vt_idx, vn_idx
            // For simplicity, let's store ref matching or compare attributes.
            // Actually, let's match exact (v_idx, vt_idx, vn_idx).
            // Wait, let's store ref in a helper or compare.
        }

        // To keep it robust and performant, let's check exact match of (v_idx, vt_idx, vn_idx):
        // (We can store an auxiliary array of ref structs for unique vertices)
        static struct { int v, vt, vn; } unique_refs[16384];

        int matched = -1;
        for (size_t j = 0; j < unique_vert_count; j++) {
            if (unique_refs[j].v == v_idx && unique_refs[j].vt == vt_idx && unique_refs[j].vn == vn_idx) {
                matched = (int)j;
                break;
            }
        }

        if (matched >= 0) {
            out_idxs[i] = (uint32_t)matched;
        } else {
            size_t new_idx = unique_vert_count++;
            unique_refs[new_idx] = (struct { int v, vt, vn; }){v_idx, vt_idx, vn_idx};

            extended_vertex_t *vert = &out_verts[new_idx];
            memset(vert, 0, sizeof(extended_vertex_t));

            if (v_idx >= 0 && (size_t)v_idx < v_count) {
                vert->x = positions[v_idx].x;
                vert->y = positions[v_idx].y;
                vert->z = positions[v_idx].z;
                vert->w = 1.0f;
            }

            if (vn_idx >= 0 && (size_t)vn_idx < vn_count) {
                vert->nx = normals[vn_idx].x;
                vert->ny = normals[vn_idx].y;
                vert->nz = normals[vn_idx].z;
                // Generate color based on normal
                vert->r = fabsf(vert->nx) * 0.5f + 0.5f;
                vert->g = fabsf(vert->ny) * 0.5f + 0.5f;
                vert->b = fabsf(vert->nz) * 0.5f + 0.5f;
                vert->a = 1.0f;
            } else {
                // Default color gradient based on position
                vert->r = fabsf(vert->x) + 0.5f;
                vert->g = fabsf(vert->y) + 0.5f;
                vert->b = fabsf(vert->z) + 0.5f;
                vert->a = 1.0f;
            }

            if (vt_idx >= 0 && (size_t)vt_idx < vt_count) {
                vert->u = texcoords[vt_idx].u;
                vert->v = texcoords[vt_idx].v;
            }

            out_idxs[i] = (uint32_t)new_idx;
        }
    }

    out_mesh->vertices = realloc(out_verts, unique_vert_count * sizeof(extended_vertex_t));
    out_mesh->num_vertices = unique_vert_count;
    out_mesh->indices = realloc(out_idxs, face_count * 3 * sizeof(uint32_t));
    out_mesh->num_indices = face_count * 3;

    free(positions);
    free(texcoords);
    free(normals);
    free(face_refs);

    return 0;
}

int parse_obj_file(const char *filename, obj_mesh_t *out_mesh) {
    if (!filename || !out_mesh) return -1;
    FILE *f = fopen(filename, "rb");
    if (!f) return -1;
    if (fseek(f, 0, SEEK_END) != 0) {
        fclose(f);
        return -1;
    }
    long len = ftell(f);
    if (len < 0) {
        fclose(f);
        return -1;
    }
    if (fseek(f, 0, SEEK_SET) != 0) {
        fclose(f);
        return -1;
    }
    char *buf = malloc(len + 1);
    if (!buf) {
        fclose(f);
        return -1;
    }
    size_t read_bytes = fread(buf, 1, len, f);
    fclose(f);
    buf[read_bytes] = '\0';

    int ret = parse_obj_string(buf, out_mesh);
    free(buf);
    return ret;
}

void free_obj_mesh(obj_mesh_t *mesh) {
    if (!mesh) return;
    free(mesh->vertices);
    free(mesh->indices);
    memset(mesh, 0, sizeof(obj_mesh_t));
}
