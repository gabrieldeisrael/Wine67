#include <stdio.h>
#include <stdlib.h>
#include "gallium_mgr.h"

int main() {
    printf("Initializing Gallium Eleven Cube Test...\n");

    struct gallium_mgr mgr;
    if (gallium_mgr_init(&mgr) != 0) {
        fprintf(stderr, "Failed to initialize Gallium manager\n");
        return 1;
    }

    printf("Gallium Eleven initialized successfully!\n");
    printf("Driver screen: %p\n", (void*)mgr.screen);
    printf("Rendering context: %p\n", (void*)mgr.context);

    printf("Simulating basic drawing pipeline...\n");
    // Here we would bind shaders, vertex buffers, and issue draw calls.
    // For now, this validates that the Gallium core is operational.

    gallium_mgr_cleanup(&mgr);
    printf("Cleanup complete. Test passed.\n");

    return 0;
}
