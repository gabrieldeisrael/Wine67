#include <stdio.h>

void parse_dxbc_shader() {
    printf("Parsing DXBC shader...\n");
}
