#ifndef PIPE_LOADER_H
#define PIPE_LOADER_H

struct pipe_loader_device;

int pipe_loader_probe(struct pipe_loader_device **devs, int nr);
void pipe_loader_release(struct pipe_loader_device **devs, int nr);

#endif
