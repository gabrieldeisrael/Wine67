#ifndef P_CONTEXT_H
#define P_CONTEXT_H

struct pipe_context {
    int dummy;
};

#endif
