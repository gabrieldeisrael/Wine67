#ifndef P_SCREEN_H
#define P_SCREEN_H

struct pipe_screen {
    int dummy;
};

#endif
